//
//  VedioTableViewCell.h
//  乐旅
//
//  Created by 姜鸥人 on 16/3/16.
//  Copyright © 2016年 姜鸥人. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VedioTableViewCell : UITableViewCell



@property(nonatomic,strong)UILabel *bigLabel;
@property(nonatomic,strong)UILabel *littleLabel;
@property(nonatomic,strong)UILabel *timeLabel;
@property(nonatomic,strong)UILabel *numberLabel;
@property(nonatomic,strong)UIImageView *VedioView;

@property(nonatomic,strong)UIButton *bt;

@end
