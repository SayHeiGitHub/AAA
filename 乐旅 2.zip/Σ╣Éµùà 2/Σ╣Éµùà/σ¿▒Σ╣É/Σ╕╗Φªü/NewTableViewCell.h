//
//  NewTableViewCell.h
//  乐旅
//
//  Created by 姜鸥人 on 16/3/16.
//  Copyright © 2016年 姜鸥人. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewTableViewCell : UITableViewCell

@property(nonatomic,strong)UIImageView *NewPic;
@property(nonatomic,strong)UILabel *NewLabel;
@property(nonatomic,strong)UILabel *NewContent;


@end
